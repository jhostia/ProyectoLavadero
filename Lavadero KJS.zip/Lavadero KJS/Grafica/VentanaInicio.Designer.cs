﻿namespace Presentacion
{
    partial class VentanaInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VentanaInicio));
            this.pnlg = new System.Windows.Forms.Panel();
            this.pnlBien = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlIniciar = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRegiInicio = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnIniciarSesion = new System.Windows.Forms.Button();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.pnlRegistrar = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtReContra = new System.Windows.Forms.TextBox();
            this.txtReCorreo = new System.Windows.Forms.TextBox();
            this.txtReUsuario = new System.Windows.Forms.TextBox();
            this.txtReConfirmarContra = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlg.SuspendLayout();
            this.pnlBien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlIniciar.SuspendLayout();
            this.pnlRegistrar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlg
            // 
            this.pnlg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(170)))), ((int)(((byte)(235)))));
            this.pnlg.Controls.Add(this.pnlIniciar);
            this.pnlg.Controls.Add(this.pnlRegistrar);
            this.pnlg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlg.Location = new System.Drawing.Point(0, 0);
            this.pnlg.Name = "pnlg";
            this.pnlg.Size = new System.Drawing.Size(1284, 611);
            this.pnlg.TabIndex = 9;
            // 
            // pnlBien
            // 
            this.pnlBien.Controls.Add(this.label11);
            this.pnlBien.Controls.Add(this.pictureBox1);
            this.pnlBien.Location = new System.Drawing.Point(3, 0);
            this.pnlBien.Name = "pnlBien";
            this.pnlBien.Size = new System.Drawing.Size(372, 304);
            this.pnlBien.TabIndex = 11;
            this.pnlBien.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(97, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(167, 25);
            this.label11.TabIndex = 28;
            this.label11.Text = ">>Bienvenido<<";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(97, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 167);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // pnlIniciar
            // 
            this.pnlIniciar.Controls.Add(this.pnlBien);
            this.pnlIniciar.Controls.Add(this.panel2);
            this.pnlIniciar.Controls.Add(this.panel3);
            this.pnlIniciar.Controls.Add(this.label4);
            this.pnlIniciar.Controls.Add(this.btnRegiInicio);
            this.pnlIniciar.Controls.Add(this.label6);
            this.pnlIniciar.Controls.Add(this.btnIniciarSesion);
            this.pnlIniciar.Controls.Add(this.txtUsuario);
            this.pnlIniciar.Controls.Add(this.txtContraseña);
            this.pnlIniciar.Location = new System.Drawing.Point(374, 122);
            this.pnlIniciar.Name = "pnlIniciar";
            this.pnlIniciar.Size = new System.Drawing.Size(372, 304);
            this.pnlIniciar.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.panel2.Location = new System.Drawing.Point(135, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(11, 42);
            this.panel2.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.panel3.Location = new System.Drawing.Point(112, 155);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(11, 42);
            this.panel3.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(68, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "Contraseña";
            // 
            // btnRegiInicio
            // 
            this.btnRegiInicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(78)))), ((int)(((byte)(107)))));
            this.btnRegiInicio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegiInicio.FlatAppearance.BorderSize = 0;
            this.btnRegiInicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.btnRegiInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegiInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegiInicio.ForeColor = System.Drawing.Color.Transparent;
            this.btnRegiInicio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegiInicio.Location = new System.Drawing.Point(135, 203);
            this.btnRegiInicio.Name = "btnRegiInicio";
            this.btnRegiInicio.Size = new System.Drawing.Size(105, 42);
            this.btnRegiInicio.TabIndex = 39;
            this.btnRegiInicio.Text = "Registrar";
            this.btnRegiInicio.UseVisualStyleBackColor = false;
            this.btnRegiInicio.Click += new System.EventHandler(this.btnRegiInicio_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(83, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "Usuario";
            // 
            // btnIniciarSesion
            // 
            this.btnIniciarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(78)))), ((int)(((byte)(107)))));
            this.btnIniciarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIniciarSesion.FlatAppearance.BorderSize = 0;
            this.btnIniciarSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.btnIniciarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIniciarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciarSesion.ForeColor = System.Drawing.Color.Transparent;
            this.btnIniciarSesion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIniciarSesion.Location = new System.Drawing.Point(115, 155);
            this.btnIniciarSesion.Name = "btnIniciarSesion";
            this.btnIniciarSesion.Size = new System.Drawing.Size(149, 42);
            this.btnIniciarSesion.TabIndex = 38;
            this.btnIniciarSesion.Text = "Iniciar Sesion";
            this.btnIniciarSesion.UseVisualStyleBackColor = false;
            this.btnIniciarSesion.Click += new System.EventHandler(this.btnIniciarSesion_Click);
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(184, 42);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(100, 20);
            this.txtUsuario.TabIndex = 0;
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(184, 89);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(100, 20);
            this.txtContraseña.TabIndex = 1;
            this.txtContraseña.UseSystemPasswordChar = true;
            // 
            // pnlRegistrar
            // 
            this.pnlRegistrar.Controls.Add(this.label1);
            this.pnlRegistrar.Controls.Add(this.txtReConfirmarContra);
            this.pnlRegistrar.Controls.Add(this.panel4);
            this.pnlRegistrar.Controls.Add(this.btnRegistrar);
            this.pnlRegistrar.Controls.Add(this.label8);
            this.pnlRegistrar.Controls.Add(this.label7);
            this.pnlRegistrar.Controls.Add(this.label5);
            this.pnlRegistrar.Controls.Add(this.txtReContra);
            this.pnlRegistrar.Controls.Add(this.txtReCorreo);
            this.pnlRegistrar.Controls.Add(this.txtReUsuario);
            this.pnlRegistrar.Location = new System.Drawing.Point(377, 122);
            this.pnlRegistrar.Name = "pnlRegistrar";
            this.pnlRegistrar.Size = new System.Drawing.Size(372, 304);
            this.pnlRegistrar.TabIndex = 9;
            this.pnlRegistrar.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.panel4.Location = new System.Drawing.Point(154, 222);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(11, 42);
            this.panel4.TabIndex = 12;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(78)))), ((int)(((byte)(107)))));
            this.btnRegistrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistrar.FlatAppearance.BorderSize = 0;
            this.btnRegistrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(95)))), ((int)(((byte)(107)))));
            this.btnRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Transparent;
            this.btnRegistrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegistrar.Location = new System.Drawing.Point(163, 222);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(101, 42);
            this.btnRegistrar.TabIndex = 40;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = false;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(27, 129);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "Contraseña";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(27, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "Correo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(27, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "Usuario";
            // 
            // txtReContra
            // 
            this.txtReContra.Location = new System.Drawing.Point(212, 129);
            this.txtReContra.Name = "txtReContra";
            this.txtReContra.Size = new System.Drawing.Size(140, 20);
            this.txtReContra.TabIndex = 2;
            this.txtReContra.UseSystemPasswordChar = true;
            // 
            // txtReCorreo
            // 
            this.txtReCorreo.Location = new System.Drawing.Point(212, 84);
            this.txtReCorreo.Name = "txtReCorreo";
            this.txtReCorreo.Size = new System.Drawing.Size(140, 20);
            this.txtReCorreo.TabIndex = 1;
            // 
            // txtReUsuario
            // 
            this.txtReUsuario.Location = new System.Drawing.Point(212, 38);
            this.txtReUsuario.Name = "txtReUsuario";
            this.txtReUsuario.Size = new System.Drawing.Size(140, 20);
            this.txtReUsuario.TabIndex = 0;
            // 
            // txtReConfirmarContra
            // 
            this.txtReConfirmarContra.Location = new System.Drawing.Point(212, 175);
            this.txtReConfirmarContra.Name = "txtReConfirmarContra";
            this.txtReConfirmarContra.Size = new System.Drawing.Size(140, 20);
            this.txtReConfirmarContra.TabIndex = 41;
            this.txtReConfirmarContra.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(27, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 20);
            this.label1.TabIndex = 42;
            this.label1.Text = "Confirmar Contraseña";
            // 
            // VentanaInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 611);
            this.Controls.Add(this.pnlg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "VentanaInicio";
            this.Text = "LAVADERO KJS";
            this.pnlg.ResumeLayout(false);
            this.pnlBien.ResumeLayout(false);
            this.pnlBien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlIniciar.ResumeLayout(false);
            this.pnlIniciar.PerformLayout();
            this.pnlRegistrar.ResumeLayout(false);
            this.pnlRegistrar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlg;
        private System.Windows.Forms.Panel pnlRegistrar;
        private System.Windows.Forms.TextBox txtReContra;
        private System.Windows.Forms.TextBox txtReCorreo;
        private System.Windows.Forms.TextBox txtReUsuario;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Panel pnlIniciar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnRegiInicio;
        private System.Windows.Forms.Button btnIniciarSesion;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Panel pnlBien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtReConfirmarContra;
    }
}